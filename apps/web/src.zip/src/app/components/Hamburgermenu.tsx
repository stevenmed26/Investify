"use client";

import { useState, useRef, useEffect } from "react";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------
interface User {
  id: string;
  email: string;
}

// ---------------------------------------------------------------------------
// API helpers
// ---------------------------------------------------------------------------
const API = process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8080";

async function apiPost(path: string, body: unknown) {
  const res = await fetch(`${API}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error ?? "Request failed");
  return data;
}

async function apiGet(path: string) {
  const res = await fetch(`${API}${path}`, { credentials: "include" });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error ?? "Request failed");
  return data;
}

// ---------------------------------------------------------------------------
// LoginCard
// ---------------------------------------------------------------------------
function LoginCard({
  user,
  onAuth,
}: {
  user: User | null;
  onAuth: (u: User | null) => void;
}) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit() {
    setError("");
    setLoading(true);
    try {
      const path = mode === "login" ? "/api/v1/auth/login" : "/api/v1/auth/register";
      const data = await apiPost(path, { email, password });
      onAuth({ id: data.id, email: data.email });
      setEmail("");
      setPassword("");
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  async function handleLogout() {
    setLoading(true);
    try {
      await apiPost("/api/v1/auth/logout", {});
      onAuth(null);
    } finally {
      setLoading(false);
    }
  }

  if (user) {
    return (
      <div className="investify-card">
        <p className="investify-card-label">Signed in</p>
        <p className="investify-card-value" title={user.email}>
          {user.email}
        </p>
        <button
          className="investify-btn investify-btn-ghost"
          onClick={handleLogout}
          disabled={loading}
        >
          {loading ? "Signing out…" : "Sign out"}
        </button>
      </div>
    );
  }

  return (
    <div className="investify-card">
      <p className="investify-card-label">
        {mode === "login" ? "Sign in" : "Create account"}
      </p>

      <input
        className="investify-input"
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        autoComplete="email"
      />
      <input
        className="investify-input"
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        autoComplete={mode === "login" ? "current-password" : "new-password"}
      />

      {error && <p className="investify-error">{error}</p>}

      <button
        className="investify-btn investify-btn-primary"
        onClick={handleSubmit}
        disabled={loading}
      >
        {loading ? "…" : mode === "login" ? "Sign in" : "Register"}
      </button>

      <button
        className="investify-btn investify-btn-ghost"
        onClick={() => {
          setMode(mode === "login" ? "register" : "login");
          setError("");
        }}
      >
        {mode === "login" ? "Need an account?" : "Already have one?"}
      </button>
    </div>
  );
}

// ---------------------------------------------------------------------------
// APIKeyCard
// ---------------------------------------------------------------------------
function APIKeyCard({ user }: { user: User | null }) {
  const [apiKey, setApiKey] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "ok" | "error">("idle");
  const [configured, setConfigured] = useState<boolean | null>(null);
  const [message, setMessage] = useState("");

  // Check provider status whenever the user changes
  useEffect(() => {
    if (!user) {
      setConfigured(null);
      return;
    }
    apiGet("/api/v1/admin/provider-status")
      .then((d) => setConfigured(d.api_key_configured ?? false))
      .catch(() => setConfigured(false));
  }, [user]);

  async function handleSave() {
    if (!apiKey.trim()) return;
    setStatus("loading");
    setMessage("");
    try {
      await apiPost("/api/v1/admin/secrets/twelvedata", { api_key: apiKey });
      setConfigured(true);
      setApiKey("");
      setStatus("ok");
      setMessage("API key saved.");
    } catch (e: unknown) {
      setStatus("error");
      setMessage(e instanceof Error ? e.message : "Failed to save key");
    }
  }

  if (!user) {
    return (
      <div className="investify-card investify-card-muted">
        <p className="investify-card-label">Twelve Data API Key</p>
        <p className="investify-card-hint">Sign in to configure your API key.</p>
      </div>
    );
  }

  return (
    <div className="investify-card">
      <p className="investify-card-label">Twelve Data API Key</p>

      <div className="investify-status-row">
        <span
          className={`investify-dot ${configured ? "investify-dot-green" : "investify-dot-gray"}`}
        />
        <span className="investify-card-hint">
          {configured === null ? "Checking…" : configured ? "Key configured" : "Not configured"}
        </span>
      </div>

      <input
        className="investify-input"
        type="password"
        placeholder={configured ? "Replace existing key…" : "Paste your API key…"}
        value={apiKey}
        onChange={(e) => setApiKey(e.target.value)}
        autoComplete="off"
      />

      {message && (
        <p className={status === "error" ? "investify-error" : "investify-success"}>
          {message}
        </p>
      )}

      <button
        className="investify-btn investify-btn-primary"
        onClick={handleSave}
        disabled={status === "loading" || !apiKey.trim()}
      >
        {status === "loading" ? "Saving…" : "Save key"}
      </button>
    </div>
  );
}

// ---------------------------------------------------------------------------
// HamburgerMenu (main export)
// ---------------------------------------------------------------------------
export function HamburgerMenu() {
  const [open, setOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const ref = useRef<HTMLDivElement>(null);

  // Restore session on mount
  useEffect(() => {
    apiGet("/api/v1/auth/me")
      .then((d) => setUser({ id: d.id, email: d.email }))
      .catch(() => setUser(null));
  }, []);

  // Close on outside click
  useEffect(() => {
    function handler(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <>
      {/* Scoped styles — no external CSS dependency */}
      <style>{STYLES}</style>

      <div className="investify-menu-root" ref={ref}>
        <button
          className={`investify-hamburger ${open ? "investify-hamburger-open" : ""}`}
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
        >
          <span />
          <span />
          <span />
          {user && <span className="investify-user-dot" />}
        </button>

        {open && (
          <div className="investify-dropdown" role="dialog" aria-label="Account panel">
            <LoginCard user={user} onAuth={setUser} />
            <APIKeyCard user={user} />
          </div>
        )}
      </div>
    </>
  );
}

// ---------------------------------------------------------------------------
// Styles (injected inline so the component is fully self-contained)
// ---------------------------------------------------------------------------
const STYLES = `
  .investify-menu-root {
    position: relative;
    display: inline-block;
  }

  /* ---- Hamburger button ---- */
  .investify-hamburger {
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 5px;
    width: 40px;
    height: 40px;
    padding: 8px;
    border: none;
    border-radius: 8px;
    background: transparent;
    cursor: pointer;
    transition: background 0.15s;
  }
  .investify-hamburger:hover {
    background: rgba(0,0,0,0.06);
  }
  .investify-hamburger span {
    display: block;
    height: 2px;
    border-radius: 2px;
    background: currentColor;
    transition: transform 0.2s, opacity 0.2s;
    transform-origin: center;
  }
  .investify-hamburger-open span:nth-child(1) {
    transform: translateY(7px) rotate(45deg);
  }
  .investify-hamburger-open span:nth-child(2) {
    opacity: 0;
    transform: scaleX(0);
  }
  .investify-hamburger-open span:nth-child(3) {
    transform: translateY(-7px) rotate(-45deg);
  }

  /* Signed-in dot badge on button */
  .investify-user-dot {
    position: absolute;
    top: 6px;
    right: 6px;
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: #22c55e;
    border: 1.5px solid white;
  }

  /* ---- Dropdown panel ---- */
  .investify-dropdown {
    position: absolute;
    right: 0;
    top: calc(100% + 8px);
    width: 280px;
    background: #ffffff;
    border: 1px solid #e5e7eb;
    border-radius: 14px;
    box-shadow: 0 8px 30px rgba(0,0,0,0.12);
    padding: 8px;
    display: flex;
    flex-direction: column;
    gap: 6px;
    z-index: 9999;
    animation: investify-fade-in 0.15s ease;
  }
  @keyframes investify-fade-in {
    from { opacity: 0; transform: translateY(-6px); }
    to   { opacity: 1; transform: translateY(0); }
  }

  /* ---- Card ---- */
  .investify-card {
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding: 14px;
    border-radius: 10px;
    background: #f9fafb;
    border: 1px solid #f3f4f6;
  }
  .investify-card-muted {
    opacity: 0.65;
  }
  .investify-card-label {
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    color: #6b7280;
    margin: 0;
  }
  .investify-card-value {
    font-size: 13px;
    font-weight: 500;
    color: #111827;
    margin: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .investify-card-hint {
    font-size: 12px;
    color: #9ca3af;
    margin: 0;
  }

  /* ---- Status row ---- */
  .investify-status-row {
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .investify-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    flex-shrink: 0;
  }
  .investify-dot-green { background: #22c55e; }
  .investify-dot-gray  { background: #d1d5db; }

  /* ---- Input ---- */
  .investify-input {
    width: 100%;
    box-sizing: border-box;
    padding: 8px 10px;
    font-size: 13px;
    border: 1px solid #e5e7eb;
    border-radius: 7px;
    background: #ffffff;
    color: #111827;
    outline: none;
    transition: border-color 0.15s, box-shadow 0.15s;
  }
  .investify-input:focus {
    border-color: #6366f1;
    box-shadow: 0 0 0 3px rgba(99,102,241,0.12);
  }
  .investify-input::placeholder {
    color: #c4c9d4;
  }

  /* ---- Buttons ---- */
  .investify-btn {
    width: 100%;
    padding: 8px 12px;
    font-size: 13px;
    font-weight: 500;
    border-radius: 7px;
    border: none;
    cursor: pointer;
    transition: background 0.15s, opacity 0.15s;
  }
  .investify-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
  .investify-btn-primary {
    background: #6366f1;
    color: #ffffff;
  }
  .investify-btn-primary:hover:not(:disabled) {
    background: #4f46e5;
  }
  .investify-btn-ghost {
    background: transparent;
    color: #6b7280;
    border: 1px solid #e5e7eb;
  }
  .investify-btn-ghost:hover:not(:disabled) {
    background: #f3f4f6;
  }

  /* ---- Feedback messages ---- */
  .investify-error {
    font-size: 12px;
    color: #ef4444;
    margin: 0;
  }
  .investify-success {
    font-size: 12px;
    color: #22c55e;
    margin: 0;
  }
`;